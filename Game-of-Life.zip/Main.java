class Main {
  public static void main(String[] args) {
    World world = new World();

    int[][] coordinates = { {2, 2}, {3, 2}, {4, 2}, {4, 1}, {3, 0} };
    world.populateCells(coordinates);
    world.display();

    for (int i = 0; i < 4; i++)
      {
        world.update();
        world.display();
      }
  }
}