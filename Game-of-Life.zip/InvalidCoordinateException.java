public class InvalidCoordinateException extends RuntimeException
  {
    public InvalidCoordinateException(String error)
    {
      super(error);
    }
  }