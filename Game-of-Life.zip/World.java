public class World
  {
    private boolean[][] world;

    public World()
    {
      this(10,10);
    }

    public World(int width, int height)
    {
      world = new boolean[width][height];
    }


    public void flipCell(int x, int y)
    {
      world[x][y] = !world[x][y];
    }
    /*

    * Takes an array of coordinates and populates the cells, e.g. { {0, 0}, {0, 1}, {1, 1} } will be made alive
    * Invalid coordinates will throw exception.
    */
    public void populateCells(int[][] coordinates) throws RuntimeException
    {
      
      
      for (int i = 0; i < coordinates.length; i++)
        {
          if (coordinates[i].length != 2)
          {
            throw new InvalidCoordinateException("Invalid coordinates. Coordinates must be in the format of {x, y}");
          }
          int x = coordinates[i][0];
          int y = coordinates[i][1];
          
          if (x < 0 || x > world.length || y < 0 || y > world[0].length)
          {
            throw new CoordinateOutOfBoundsException("Coordinate out of bounds. Keep coordinates within dimensions of world.");
          }

          world[x][y] = true;
        }
      
    }

    /*

    * Takes an array of coordinates and kills the cells, e.g. { {0, 0}, {0, 1}, {1, 1} } will be made dead
    * Invalid coordinates will throw exception.
    */
    public void depopulateCells(int[][] coordinates) throws RuntimeException
    {
      for (int i = 0; i < coordinates.length; i++)
        {
          if (coordinates[i].length != 2)
          {
            throw new InvalidCoordinateException("Invalid coordinates. Coordinates must be in the format of {x, y}");
          }
          int x = coordinates[i][0];
          int y = coordinates[i][1];
          
          if (x < 0 || x > world.length || y < 0 || y > world[0].length)
          {
            throw new CoordinateOutOfBoundsException("Coordinate out of bounds. Keep coordinates within dimensions of world.");
          }

          world[x][y] = false;
        }
    }
    
    public void update()
    {
      boolean[][] newWorld = new boolean[world.length][world[0].length];
      for (int x = 0; x < world.length; x++)
        {
          for (int y = 0; y < world[0].length; y++)
            {
              newWorld[x][y] = checkCell(x, y);
            }
        }
      world = newWorld;
    }
    
    public void display()
    {
      String border = "";
      for (int i = 0; i < world.length; i++)
        {
          border += "- ";
        }
      
      System.out.println(border);
      System.out.print(this);
      System.out.println(border);
    }
    
    public String toString()
    {
      String board = "";
      for (int y = 0; y < world[0].length; y++)
        {
          for (int x = 0; x < world.length; x++)
            {
              if (world[x][y])
              {
                board += "1 ";
              }
              else
              {
                board += "0 ";
              }
            }
          board += "\n";
        }
      return board;
    }

    private int numberOfNeighbours(int x, int y)
    {
      int count = 0;
      for (int i = x - 1; i <= x + 1; i++)
        {
          for (int j = y - 1; j <= y + 1; j++)
            {
              if (!(i < 0 || i >= world.length || j < 0 || j >= world[0].length || (i == x && j == y)) && world[i][j])
              {
                count++;
              }
            }
        }
      return count;
    }

    private boolean checkCell(int x, int y)
    {
      int num = numberOfNeighbours(x, y);
      if (num < 2 || num > 3)
      {
        return false;
      }
      if (num == 3)
      {
        return true;
      }
      return world[x][y];
    }


  }