public class CoordinateOutOfBoundsException extends RuntimeException
  {
    public CoordinateOutOfBoundsException(String error)
    {
      super(error);
    }
  }